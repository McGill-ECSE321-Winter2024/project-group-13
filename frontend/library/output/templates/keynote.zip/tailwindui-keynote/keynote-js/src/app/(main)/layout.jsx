import { Layout } from '@/components/Layout'

export default function MainLayout({ children }) {
  return <Layout>{children}</Layout>
}
